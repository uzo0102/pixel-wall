import "dotenv/config";
import express from "express";
import helmet from "helmet";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import midtransClient from "midtrans-client";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const pricePerPixel = Number(process.env.PRICE_PER_PIXEL || 1000);
const isProduction = String(process.env.MIDTRANS_IS_PRODUCTION).toLowerCase() === "true";
const baseUrl = process.env.BASE_URL || `http://localhost:${port}`;

if (!Number.isInteger(pricePerPixel) || pricePerPixel < 1) {
  throw new Error("PRICE_PER_PIXEL must be a positive integer.");
}

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://app.sandbox.midtrans.com", "https://app.midtrans.com"],
      connectSrc: ["'self'", "https://api.sandbox.midtrans.com", "https://api.midtrans.com"],
      frameSrc: ["'self'", "https://app.sandbox.midtrans.com", "https://app.midtrans.com"],
      imgSrc: ["'self'", "data:", "https:"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: "32kb" }));
app.use(express.urlencoded({ extended: false, limit: "32kb" }));

const dataDir = path.join(__dirname, "data");
import { mkdirSync } from "node:fs";
mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "pixel-wall.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  ad_name TEXT NOT NULL,
  target_url TEXT NOT NULL,
  image_url TEXT,
  pixels_json TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('pending','paid','failed','expired')),
  provider_order_id TEXT NOT NULL UNIQUE,
  payment_url TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at TEXT
);
CREATE TABLE IF NOT EXISTS ads (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL UNIQUE REFERENCES orders(id),
  ad_name TEXT NOT NULL,
  target_url TEXT NOT NULL,
  image_url TEXT,
  pixels_json TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
`);

const snap = new midtransClient.Snap({
  isProduction,
  serverKey: process.env.MIDTRANS_SERVER_KEY || "MISSING_SERVER_KEY",
  clientKey: process.env.MIDTRANS_CLIENT_KEY || "MISSING_CLIENT_KEY"
});

function cleanText(value, max) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function validHttpUrl(value, optional = false) {
  if (optional && !value) return true;
  try {
    const u = new URL(value);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch { return false; }
}
function parsePixels(input) {
  if (!Array.isArray(input) || input.length < 1 || input.length > 10000) return null;
  const values = [...new Set(input)];
  if (values.length !== input.length) return null;
  if (!values.every(n => Number.isInteger(n) && n >= 0 && n < 10000)) return null;
  return values.sort((a, b) => a - b);
}
function occupiedPixels() {
  const rows = db.prepare(`
    SELECT pixels_json FROM orders WHERE status = 'pending'
    UNION ALL
    SELECT pixels_json FROM ads WHERE active = 1
  `).all();
  const used = new Set();
  for (const row of rows) {
    try { JSON.parse(row.pixels_json).forEach(p => used.add(p)); } catch {}
  }
  return used;
}
function safeOrder(row) {
  return {
    id: row.id, adName: row.ad_name, targetUrl: row.target_url,
    imageUrl: row.image_url, pixels: JSON.parse(row.pixels_json),
    amount: row.amount, status: row.status, paymentUrl: row.payment_url,
    createdAt: row.created_at, paidAt: row.paid_at
  };
}
function adminAuthorized(req) {
  const expected = process.env.ADMIN_TOKEN;
  const supplied = req.get("x-admin-token");
  return Boolean(expected && supplied && crypto.timingSafeEqual(
    Buffer.from(String(supplied)), Buffer.from(String(expected))
  ));
}
const paidTransactionStatuses = new Set(["settlement", "capture"]);
const failTransactionStatuses = new Set(["deny", "cancel", "expire", "failure"]);

app.get("/api/config", (_req, res) => {
  res.json({
    pricePerPixel,
    bankName: process.env.BANK_NAME || "BCA",
    accountNumber: process.env.BANK_ACCOUNT_NUMBER || "",
    accountHolder: process.env.BANK_ACCOUNT_HOLDER || "",
    paymentConfigured: Boolean(process.env.MIDTRANS_SERVER_KEY && process.env.MIDTRANS_CLIENT_KEY),
    midtransClientKey: process.env.MIDTRANS_CLIENT_KEY || "",
    midtransIsProduction: isProduction
  });
});

app.get("/api/ads", (_req, res) => {
  const rows = db.prepare(`
    SELECT id, ad_name, target_url, image_url, pixels_json, created_at
    FROM ads WHERE active = 1 ORDER BY created_at DESC
  `).all();
  res.json(rows.map(row => ({
    id: row.id, name: row.ad_name, url: row.target_url, imageUrl: row.image_url,
    pixels: JSON.parse(row.pixels_json), createdAt: row.created_at
  })));
});

app.get("/api/pixels/availability", (_req, res) => {
  res.json({ occupied: [...occupiedPixels()] });
});

app.post("/api/orders", async (req, res) => {
  try {
    if (!process.env.MIDTRANS_SERVER_KEY || !process.env.MIDTRANS_CLIENT_KEY) {
      return res.status(503).json({ error: "Payment provider is not configured yet." });
    }
    const adName = cleanText(req.body?.adName, 60);
    const targetUrl = cleanText(req.body?.targetUrl, 500);
    const imageUrl = cleanText(req.body?.imageUrl, 1000);
    const pixels = parsePixels(req.body?.pixels);
    if (!adName || !validHttpUrl(targetUrl) || !validHttpUrl(imageUrl, true) || !pixels) {
      return res.status(400).json({ error: "Please provide valid ad details and pixel selection." });
    }
    const amount = pixels.length * pricePerPixel;
    if (!Number.isSafeInteger(amount) || amount < 1) {
      return res.status(400).json({ error: "Invalid order amount." });
    }

    const createOrder = db.transaction(() => {
      const used = occupiedPixels();
      if (pixels.some(p => used.has(p))) return null;
      const id = crypto.randomUUID();
      const providerOrderId = `PW-${id}`;
      db.prepare(`INSERT INTO orders
        (id, ad_name, target_url, image_url, pixels_json, amount, status, provider_order_id)
        VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)`)
        .run(id, adName, targetUrl, imageUrl || null, JSON.stringify(pixels), amount, providerOrderId);
      return { id, providerOrderId, amount };
    });
    const created = createOrder();
    if (!created) return res.status(409).json({ error: "Some selected pixels are no longer available. Refresh and select again." });

    try {
      const result = await snap.createTransaction({
        transaction_details: { order_id: created.providerOrderId, gross_amount: created.amount },
        item_details: [{
          id: "pixel-wall-ad", price: pricePerPixel, quantity: pixels.length,
          name: `Pixel Wall ad (${pixels.length} pixels)`
        }],
        custom_field1: created.id,
        callbacks: { finish: `${baseUrl}/?order=${encodeURIComponent(created.id)}` }
      });
      db.prepare("UPDATE orders SET payment_url = ? WHERE id = ?").run(result.redirect_url, created.id);
      return res.status(201).json({
        orderId: created.id, amount: created.amount,
        paymentUrl: result.redirect_url, status: "pending"
      });
    } catch (error) {
      db.prepare("UPDATE orders SET status = 'failed' WHERE id = ? AND status = 'pending'").run(created.id);
      console.error("Payment creation failed:", error?.message || "unknown error");
      return res.status(502).json({ error: "Could not create payment. Please try again later." });
    }
  } catch (error) {
    console.error("Order error:", error?.message || "unknown error");
    res.status(500).json({ error: "Could not create order." });
  }
});

app.get("/api/orders/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Order not found." });
  const order = safeOrder(row);
  // Never expose personal data or provider secrets here.
  res.json({ id: order.id, amount: order.amount, status: order.status, adName: order.adName });
});

app.post("/api/payments/midtrans-notification", async (req, res) => {
  try {
    const body = req.body || {};
    if (!body.order_id || !body.status_code || !body.gross_amount || !body.signature_key) {
      return res.status(400).json({ error: "Invalid notification." });
    }
    const expected = crypto.createHash("sha512")
      .update(`${body.order_id}${body.status_code}${body.gross_amount}${process.env.MIDTRANS_SERVER_KEY}`)
      .digest("hex");
    const a = Buffer.from(expected);
    const b = Buffer.from(String(body.signature_key));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(401).json({ error: "Invalid signature." });
    }
    const order = db.prepare("SELECT * FROM orders WHERE provider_order_id = ?").get(body.order_id);
    if (!order) return res.status(404).json({ error: "Order not found." });
    if (Number(body.gross_amount) !== order.amount) {
      return res.status(400).json({ error: "Amount mismatch." });
    }

    // Verify transaction state with the provider API rather than trusting the webhook alone.
    const transaction = await snap.transaction.status(body.order_id);
    const status = transaction.transaction_status;
    const paid = paidTransactionStatuses.has(status) &&
      (!transaction.fraud_status || transaction.fraud_status === "accept");
    if (paid) {
      const activate = db.transaction(() => {
        const latest = db.prepare("SELECT * FROM orders WHERE id = ?").get(order.id);
        if (!latest || latest.status === "paid") return;
        // Final conflict check excludes this order; other pending orders still reserve their pixels.
        const otherRows = db.prepare(`
          SELECT pixels_json FROM orders WHERE status = 'pending' AND id != ?
          UNION ALL SELECT pixels_json FROM ads WHERE active = 1
        `).all(order.id);
        const occupied = new Set();
        for (const r of otherRows) JSON.parse(r.pixels_json).forEach(p => occupied.add(p));
        const pixels = JSON.parse(latest.pixels_json);
        if (pixels.some(p => occupied.has(p))) {
          // A rare conflict must not silently activate overlapping inventory.
          db.prepare("UPDATE orders SET status = 'failed' WHERE id = ?").run(order.id);
          return;
        }
        db.prepare("UPDATE orders SET status = 'paid', paid_at = CURRENT_TIMESTAMP WHERE id = ?").run(order.id);
        db.prepare(`INSERT OR IGNORE INTO ads
          (id, order_id, ad_name, target_url, image_url, pixels_json, active)
          VALUES (?, ?, ?, ?, ?, ?, 1)`)
          .run(crypto.randomUUID(), order.id, latest.ad_name, latest.target_url, latest.image_url, latest.pixels_json);
      });
      activate();
    } else if (failTransactionStatuses.has(status)) {
      db.prepare("UPDATE orders SET status = ? WHERE id = ? AND status = 'pending'")
        .run(status === "expire" ? "expired" : "failed", order.id);
    }
    res.status(200).json({ received: true });
  } catch (error) {
    console.error("Notification handling failed:", error?.message || "unknown error");
    res.status(500).json({ error: "Notification processing failed." });
  }
});

app.get("/api/admin/orders", (req, res) => {
  if (!adminAuthorized(req)) return res.status(401).json({ error: "Unauthorized." });
  const rows = db.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 500").all();
  res.json(rows.map(safeOrder));
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.use((err, _req, res, _next) => {
  console.error("Unhandled request error:", err?.message || "unknown error");
  res.status(500).json({ error: "Unexpected server error." });
});

app.listen(port, () => {
  console.log(`Pixel Wall running on ${baseUrl}`);
  console.log(`Payment mode: ${isProduction ? "PRODUCTION" : "SANDBOX"}`);
});
