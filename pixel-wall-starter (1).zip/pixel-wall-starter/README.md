# Pixel Wall — starter project

This project contains:
- A responsive 10,000-pixel grid
- Indonesian/English UI
- Price calculation (default Rp1,000 per pixel)
- Shared server-backed ad gallery
- SQLite persistence for local development
- Order creation with Midtrans Snap
- Signed payment-notification validation plus server-side transaction status verification
- Ads activate only after the server verifies a successful payment

## Important: not live-ready until configured and deployed

This is a starter implementation, not an already-connected bank account. You must have a merchant account approved by the payment provider, configure credentials, deploy to HTTPS, configure the notification URL, and test end-to-end. Do not accept live payments until those steps and testing are complete.

Since the bank account belongs to a guardian, have the guardian handle merchant registration, settlement account information, and provider terms. Never put a bank PIN, password, OTP, or payment-provider server key in frontend code or share them in chat.

## Run locally

Requirements: Node.js 20+.

1. Extract this ZIP.
2. Copy `.env.example` to `.env`.
3. Fill `ADMIN_TOKEN` with a long random value. Keep `.env` private.
4. Add Midtrans **Sandbox** server/client keys to `.env`.
5. Install and run:

   ```bash
   npm install
   npm start
   ```

6. Open `http://localhost:3000`.

The site must be served by the Node server. Do not open `public/index.html` as a `file://` URL.

## Payment provider setup

1. Create/complete the merchant account with help from the account owner/guardian.
2. Use Sandbox credentials first.
3. In the provider dashboard, set the payment notification URL to:
   `https://YOUR-DOMAIN.example/api/payments/midtrans-notification`
4. Set `BASE_URL` to your public HTTPS origin.
5. Test success, failure, expiry, repeated notifications, and two users trying to buy overlapping pixels.
6. Switch `MIDTRANS_IS_PRODUCTION=true` only after merchant approval and successful end-to-end tests, using production credentials.

Payment methods available to buyers depend on the provider's current account configuration. Verify that the intended BCA payment methods are enabled before launch.

## Hosting / database note

The included SQLite database is suitable for local development or a single persistent server instance. Many serverless/free hosting platforms have ephemeral filesystems; on those platforms, use a managed PostgreSQL database and adapt the database layer before going live. Keep the payment webhook public, but protect administrative endpoints.

## Environment variables

- `PORT`: server port
- `BASE_URL`: public HTTPS origin
- `ADMIN_TOKEN`: secret token for the private admin orders endpoint
- `MIDTRANS_SERVER_KEY`: server-only payment key
- `MIDTRANS_CLIENT_KEY`: public checkout client key
- `MIDTRANS_IS_PRODUCTION`: `false` for sandbox, `true` for production
- `BANK_NAME`, `BANK_ACCOUNT_NUMBER`, `BANK_ACCOUNT_HOLDER`: optional display information only; they do not prove a payment
- `PRICE_PER_PIXEL`: integer price in IDR

## Endpoints

- `GET /api/config`
- `GET /api/ads`
- `GET /api/pixels/availability`
- `POST /api/orders`
- `GET /api/orders/:id`
- `POST /api/payments/midtrans-notification`
- `GET /api/admin/orders` with header `x-admin-token: YOUR_ADMIN_TOKEN`

## Security / production checklist

- Deploy only over HTTPS.
- Keep `.env` and provider server key private.
- Use a managed database with backups for a multi-instance deployment.
- Add rate limiting, abuse protection, moderation of ad links/images, retention policy, and admin authentication before public launch.
- Configure CSP carefully if the payment provider changes checkout domains.
- Review provider documentation and local requirements with the guardian.
- Do not mark ads paid from a browser redirect; only verified server-side payment status should activate an ad.
